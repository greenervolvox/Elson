//criando variáveis que registram os campos do form
const formulario = document.querySelector("form");
//o I de Inome é de input
const Inome=document.querySelector(".nome");
const Iemail=document.querySelector(".email");
const Isenha=document.querySelector(".senha");
const Itel=document.querySelector(".tel");

//função comum pra esse tipo de processo
function cadastrar(){

    fetch("http://localhost:8080/usuarios",
    {
        //cabecalho.. informando q vou mandar um JSON
        headers:{
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        //metodo POST pra enviar
        method: "POST",
        //o JSON stringify é um conversor pra JSON
        body: JSON.stringify({
            nome: Inome.value,
            email: Iemail.value,
            senha: Isenha.value,
            telefone: Itel.value
        })
    })
    .then(function(res) {console.log(res)})
    .catch(function(res) {console.log(res)})
};

function limpar(){
    Inome.value = "";
    Iemail.value = "";
    Isenha.value = "";
    Itel.value = "";
}

formulario.addEventListener('submit', function (event) {
    event.preventDefault();

    cadastrar();
    //funcao limpar pra limpar os campos após digitá-los
    limpar()
});